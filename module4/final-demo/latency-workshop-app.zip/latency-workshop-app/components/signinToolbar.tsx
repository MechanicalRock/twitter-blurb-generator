import * as React from "react";

import { Box, Button } from "@mui/material";
import { signIn, signOut, useSession } from "next-auth/react";

function AuthenticatedContent({ username }: { username?: string | null }) {
  return (
    <div>
      <span className="mr-3">
        Welcome <b className="text-green-500">{username}!</b>
      </span>

      <Button
        variant="contained"
        size="medium"
        color="primary"
        onClick={() => {
          signOut({ redirect: true });
        }}
      >
        Sign Out
      </Button>
    </div>
  );
}

function UnauthenticatedContent() {
  return (
    <Button
      variant="contained"
      size="medium"
      color="primary"
      onClick={() => {
        signIn("twitter", {
          callbackUrl: process.env.NEXTAUTH_URL,
        });
      }}
    >
      Login With Twitter
    </Button>
  );
}

export default function SigninToolbar() {
  const { data: session, status } = useSession();

  return (
    <Box position="absolute" top="1em" right="1em">
      {status === "authenticated" ? (
        <AuthenticatedContent username={session.user?.name} />
      ) : (
        <UnauthenticatedContent />
      )}
    </Box>
  );
}
