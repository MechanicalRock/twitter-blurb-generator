import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  TextField,
} from "@mui/material";

import { CenterBox } from "./centerBox";
import { ProfilePicture } from "./profilePicture";
import TwitterIcon from "@mui/icons-material/Twitter";
import { toast } from "react-hot-toast";
import { useState } from "react";

export const TweetPreview = ({ blurb }: { blurb: string }) => {
  const [editableBlurb, setEditableBlurb] = useState(blurb);
  const [loading, setLoading] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [error, setError] = useState<string>();

  const tweet = async () => {
    try {
      setLoading(true);
      setError(undefined);
      const res = await fetch("/api/tweetPost", {
        method: "POST",
        body: JSON.stringify({
          message: blurb,
        }),
      });

      const errors = (await res.json()).errors;
      if (Array.isArray(errors) && errors.length > 0) {
        throw new Error(errors[0].message);
      } else {
        toast("Tweet Posted!");
        setShowDialog(false);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <TwitterIcon
        className="cursor-pointer"
        onClick={() => setShowDialog(true)}
      />
      <Dialog
        open={showDialog}
        onClose={() => setShowDialog(false)}
        fullWidth
        sx={{ maxWidth: 600, mx: "auto" }}
      >
        <DialogTitle>Tweet Preview</DialogTitle>
        <DialogContent sx={{ position: "relative" }}>
          {loading && (
            <CenterBox
              sx={{
                backgroundColor: "white",
                zIndex: 1,
                opacity: 0.5,
              }}
            >
              <CircularProgress color="primary" />
            </CenterBox>
          )}
          <Stack direction="row">
            <ProfilePicture />
            <Box width={"100%"}>
              {error && <p className="text-red-500">{error}</p>}
              <TextField
                fullWidth
                minRows={4}
                multiline
                onChange={(e) => setEditableBlurb(e.target.value)}
                sx={{ "& textarea": { boxShadow: "none !important" } }}
                value={editableBlurb}
                variant="standard"
              />
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowDialog(false)} disabled={loading}>
            Close
          </Button>
          <Button
            onClick={tweet}
            disabled={loading}
            variant="contained"
            color="primary"
          >
            Tweet
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
