import { useSession } from "next-auth/react";

export const ProfilePicture = () => {
  const { data: session } = useSession();
  const twitterImage = session?.user?.image;

  return (
    <>
      {twitterImage && (
        <img
          src={twitterImage}
          alt="User's Twitter Profile Picture"
          style={{
            height: "3em",
            width: "auto",
            borderRadius: "50%",
            marginRight: "1em",
          }}
        />
      )}
    </>
  );
};
