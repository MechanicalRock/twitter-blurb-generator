import { NextApiRequest, NextApiResponse } from "next";

import { getToken } from "next-auth/jwt";

type TweetRequest = {
  message: string;
};
/*
    Given Twitter has been authenticated
    And a TweetRequest has been provided
    Then post the tweet to Twitter
*/
export default async (req: NextApiRequest, res: NextApiResponse) => {
  try {
    // Validate Token
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token) {
      throw new Error("Not authorised, please login to Twitter first");
    }

    // Validate Request
    const body = JSON.parse(req.body) as TweetRequest;
    if (!body.message) {
      throw new Error("No message provided");
    }

    // Post Tweet
    const response = await fetch("https://api.twitter.com/2/tweets", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token.access_token}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        text: body.message,
      }),
    });

    const details = await response.json();
    res.status(response.ok ? 201 : 400).send(details);
  } catch (e) {
    res.status(500).send((e as Error).message);
  }
};
