import NextAuth from "next-auth";
import TwitterProvider from "next-auth/providers/twitter";

// File naming: the brackets [ define our API route as a parameter (or variable) and the ... tells Next.js that there can be more than one parameter

const twitterProvider = TwitterProvider({
  clientId: process.env.TWITTER_CLIENT_ID || "",
  clientSecret: process.env.TWITTER_CLIENT_SECRET || "",
  authorization: {
    url: "https://twitter.com/i/oauth2/authorize",
    params: {
      scope: "users.read tweet.read tweet.write offline.access",
    },
  },
  version: "2.0",
});

export default NextAuth({
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async jwt({ account, token }) {
      if (account) {
        token.refresh_token = account.refresh_token;
        token.access_token = account.access_token;
      }

      return token;
    },
  },
  providers: [twitterProvider],
});
